from tests.selenium.pages.login.login import LoginPage
from tests.selenium.pages.dashboard.dashboard import DashboardPage
from config import STEPHUSERNAME, STEPHPASSWORD
import re
import pytest


class TestLogin:

    def test_get_login_form(self, browser):
        login_page = LoginPage(browser)
        login_form = login_page.get_login_form()
        login_page.take_screenshot("login_page")

        assert login_form.is_displayed(), "Login form should be displayed"

    def test_get_title(self, browser):
        login_page = LoginPage(browser)
        title = login_page.get_title()
        assert title == 'SmartServer CMS', f"Unexpected title: {title}"

    def test_login_with_valid_credentials(self, browser):
        login_page = LoginPage(browser)
        login_page.enter_credentials(STEPHUSERNAME, STEPHPASSWORD)
        login_page.click_login_button()
        login_page.wait_for_redirection()
        login_page.take_screenshot("dashboard_page")
        assert browser.current_url == login_page.landed_url, "Login was not successful"

    @pytest.mark.negative
    def test_login_with_invalid_credentials(self, browser):
        login_page = LoginPage(browser)
        login_page.enter_credentials("invalid_username", "invalid_password")
        login_page.click_login_button()

        failed_login_response = login_page.get_invalid_login_response()
        assert failed_login_response == "Incorrect login or password", f"Unexpected login response: {failed_login_response}"

    def test_login_and_get_version(self, browser):
        login_page = LoginPage(browser)
        login_page.do_successful_login(STEPHUSERNAME, STEPHPASSWORD)

        dashboard_page = DashboardPage(browser)
        version = dashboard_page.get_version()
        login_page.take_screenshot("version")
        assert re.match(r'^\d+\.\d+\.\d+$', version), f"Invalid version format: {version}"

    def test_login_and_get_mode(self, browser):
        login_page = LoginPage(browser)
        login_page.do_successful_login(STEPHUSERNAME, STEPHPASSWORD)
        
        dashboard_page = DashboardPage(browser)
        mode = dashboard_page.get_mode()
        assert mode == "DMM", f"Invalid mode: {mode}"
    