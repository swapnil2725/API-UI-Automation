from tests.selenium.pages.login.login_locators import LoginPageLocators
from config import BASE_URI
from pages.base_page import BasePage

class LoginPage(BasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.login_page = "#/login"
        self.driver.get(f"{BASE_URI}{self.login_page}")
        self.landed_url = f"{BASE_URI}#/dashboard"

    def wait_for_redirection(self):
        self.wait.until(lambda driver: driver.current_url != f"{BASE_URI}{self.login_page}")

    def get_login_form(self):
        return self.wait_for_element_to_be_visible(LoginPageLocators.LOGIN_FORM)

    def enter_credentials(self, username, password):
        username_input = self.wait_for_element_to_be_visible(LoginPageLocators.USERNAME_INPUT)
        password_input = self.wait_for_element_to_be_visible(LoginPageLocators.PASSWORD_INPUT)
        username_input.send_keys(username)
        password_input.send_keys(password)

    def click_login_button(self):
        login_button = self.wait_for_element_to_be_visible(LoginPageLocators.LOGIN_BUTTON)
        login_button.click()

    def get_invalid_login_response(self):
        invalid_login_response = self.wait_for_element_to_be_visible(LoginPageLocators.INVALID_LOGIN_MESSAGE)
        return invalid_login_response.text
    
    def do_successful_login(self, username, password):
        self.enter_credentials(username, password)
        self.click_login_button()
        self.wait_for_redirection()