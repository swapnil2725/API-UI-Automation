from pages.base_locators import BaseLocator


class LoginPageLocators(BaseLocator):
    
    default_parent = "login-dialog"
    LOGIN_FORM = BaseLocator.get_locator("login-form", "mat-dialog-content", "class", parent=default_parent)
    USERNAME_INPUT = BaseLocator.get_locator("username", "input", parent=default_parent)
    PASSWORD_INPUT = BaseLocator.get_locator("password", "input", parent=default_parent)
    LOGIN_BUTTON = BaseLocator.get_locator("login", "button", parent=default_parent)
    INVALID_LOGIN_MESSAGE = BaseLocator.get_locator("error", "div", "data-ata-el", parent=default_parent)