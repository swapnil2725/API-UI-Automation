from selenium.webdriver.common.by import By

class BaseLocator:
    ata_locator_tag = "data-ata-name"
    locator_type = ""
    parent = ""

    @classmethod
    def get_locator(cls, locator_value, locator_type=None, locator_tag=None, parent=None):
        locator_tag = locator_tag or cls.ata_locator_tag
        locator_type = locator_type or cls.locator_type
        parent = parent or cls.parent
        return (By.CSS_SELECTOR, f"{parent} {locator_type}[{locator_tag}*={locator_value}]")