from selenium.webdriver.common.by import By
from pages.base_locators import BaseLocator

base_locators = BaseLocator()
class DashboardLocators:

    VERSION = base_locators.get_locator("version")
    MODE = base_locators.get_locator("mode")