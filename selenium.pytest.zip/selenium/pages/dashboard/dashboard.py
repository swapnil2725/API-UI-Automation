from tests.selenium.pages.dashboard.dashboard_locators import DashboardLocators
from config import BASE_URI
from pages.base_page import BasePage

class DashboardPage(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

    def get_version(self):
        version_element = self.wait_for_element_to_be_visible(DashboardLocators.VERSION)
        return version_element.text
    
    def get_mode(self):
        version_element = self.wait_for_element_to_be_visible(DashboardLocators.MODE)
        return version_element.text
